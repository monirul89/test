from django.shortcuts import redirect, render
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from myapp.models import Slide_list

# Create your views here.

def image_edit(request, id):

    if request.method == 'POST':    
        rm_image        = request.FILES.get('image')
        rm_image2        = request.FILES.get('image2')
        print('MMMMMM', rm_image) 
        
        if rm_image:
            file_name = default_storage.get_available_name(rm_image.name) 
            file_path = default_storage.save('slide/' + file_name, ContentFile(rm_image.read())) 
            rm_image = str("/media/")+file_path

            Slide_list.objects.create( first_name='First slide', slide_image = rm_image)

        if rm_image2:
            file_name2 = default_storage.get_available_name(rm_image2.name) 
            file_path2 = default_storage.save('slide/' + file_name2, ContentFile(rm_image2.read())) 
            rm_image2 = str("/media/")+file_path2

            Slide_list.objects.create( small_image = rm_image2)
        
        return redirect("/images")

    return render(request, "home/index.html")
    

def home_page(request):
    if request.method == 'GET':
        data = Slide_list.objects.all().order_by('-id')
        context = {
            'images':data
        }
        return render(request, "home/index.html", context)
    
    elif request.method == 'POST':    
        rm_image        = request.FILES.get('image')
        rm_image2        = request.FILES.get('image2')
        print('MMMMMM', rm_image) 
        
        if rm_image:
            file_name = default_storage.get_available_name(rm_image.name) 
            file_path = default_storage.save('slide/' + file_name, ContentFile(rm_image.read())) 
            rm_image = str("/media/")+file_path

            Slide_list.objects.create( first_name='First slide', slide_image = rm_image)

        if rm_image2:
            file_name2 = default_storage.get_available_name(rm_image2.name) 
            file_path2 = default_storage.save('slide/' + file_name2, ContentFile(rm_image2.read())) 
            rm_image2 = str("/media/")+file_path2

            Slide_list.objects.create( small_image = rm_image2)

        context = {
            "image":rm_image,
            "image2":rm_image2,
        }
        return render(request, "home/index.html", context)