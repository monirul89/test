from django.db import models

# Create your models here.

class Slide_list(models.Model):
    first_name       = models.CharField(max_length=100, blank=True, null=True)
    slide_image      = models.ImageField(upload_to='slide/', blank=True, null=True)
    small_image      = models.ImageField(upload_to='slide/', blank=True, null=True)