

from django.urls import path
from . import views

urlpatterns = [
    path('images/', views.home_page, name="home_page"),
    path('images/<int:id>/', views.image_edit, name="image_edit"),
]
